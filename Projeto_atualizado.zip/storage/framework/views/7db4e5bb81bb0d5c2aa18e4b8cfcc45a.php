<?php $__env->startSection('content'); ?>
    <div
        id="app"
        data-page="dashboard"
        data-user-name="<?php echo e(auth()->user()->name); ?>"
        class="min-h-screen"
    ></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.react', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/resources/views/dashboard.blade.php ENDPATH**/ ?>