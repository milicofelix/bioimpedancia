<?php $__env->startSection('content'); ?>
    <div
        id="app"
        data-page="login"
        class="min-h-screen"
    ></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.react', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/adrianofreitas/www/general-projects/ricostyemagrecimento/resources/views/auth/login.blade.php ENDPATH**/ ?>